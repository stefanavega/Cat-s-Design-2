<?php require 'src/header.php'?>

<div class="mt-5" style="height: 100%">
    <div id="fullpage">
        <div class="section" id="section0">
            <div class="content container-fluid pl-5 pr-5">
                <div class="col-12 text-left">
                    <div class="row h1decoration">
                        <div class="col-12 mb-5">
                            <h1 class="text-uppercase">Leave a message</h1>
                            <div class="deco_title" style="top: 42px"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <form class="text-uppercase" method="post">
                                <div class="row">
                                    <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 text-left">
                                        <div class="form-group mb-5">
                                            <label for="name">Name</label>
                                            <input type="text" class="form-control left" id="name" placeholder="Name" required name="name">
                                        </div>
                                        <div class="form-group mb-5">
                                            <label for="surname">Surname</label>
                                            <input type="text" class="form-control left" id="surname" placeholder="Surname" required name="surname">
                                        </div>
                                        <div class="form-group mb-5">
                                            <label for="email">Email address</label>
                                            <input type="email" class="form-control left" id="email" placeholder="name@example.com" required name="email">
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 rightinputs text-right">
                                        <div class="form-group">
                                            <label for="message">Leave us a message if you'd like!</label>
                                            <textarea class="form-control right" id="message" rows="5" placeholder="Write here!" required name="message" maxlenght="1500"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <div class="col-6 text-left">
                                        <button type="reset" class="btn appointment text-uppercase left text-left">Reset</button>
                                    </div>
                                    <div class="offset-0 col-6 text-right">
                                        <button type="submit" class="btn appointment text-uppercase right text-right">Submit</button>
                                    </div>
                                </div>
                            </form>
                            <div class="row text-center">
                                <div class="col-12 mb-5">
                                    <h5 class="gotocontact">In case you wish to make an appointment click <a href="contact.php">here</a>!</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="section" id="section1">
            <div class="content container-fluid pl-5 pr-5">
                <div class="row h1decoration">
                    <div class="col-12 mb-5 text-left">
                        <h1 class="pt-5 text-uppercase">Contact information</h1>
                        <div class="deco_title"></div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 address">
                        <address>
                Cat's Design <br>
                7 Mercy Street, Ap 7 <br>
                Timisoara, TM 300085 <br>
                Ph: +04 (0356) 356 356 <br>
                    <a href="#" class="socialmedia">Facebook</a> | <a href="#" class="socialmedia">Instagram</a>
            </address>

                    </div>
                    <div class="col-12 col-sm-12 col-md-12 col-lg-9 col-xl-9">
                        <div id="map" class="map mb-5"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
    $(window).resize(function() {
        if ($(window).width() < 992) {
            window.location = "contact.php"
        };
    });
    if ($(window).width() < 992) {
        window.location = "contact.php"
    };

</script>

<?php require 'src/add/addmessage.php'?>
<?php require 'src/footer.php'?>
