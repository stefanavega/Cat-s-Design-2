<!DOCTYPE html>
<html lang="ro">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cat's Design</title>
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans:300,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Istok+Web" rel="stylesheet">
    <link href="https://use.fontawesome.com/releases/v5.0.2/css/all.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/jquery.es-drawermenu.min.css">
    <link rel="stylesheet" type="text/css" href="css/datepicker.css">
    <link rel="stylesheet" type="text/css" href="css/jquery.fullPage.css" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style1.css">
</head>

<body>
    <header>
        <div class="navbar">
            <div class="menu-left">
                <svg version="1.1" class="hamburger drawer-toggle" id="hamburger" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 302 212.9" style="enable-background:new 0 0 302 212.9;" xml:space="preserve">
              <g><rect width="302" height="26.3" /></g>
              <g><rect y="93.3" width="302" height="26.3"/></g>
              <g><rect y="186.7" width="302" height="26.3"/></g>
            </svg>
            </div>
            <div class="menu-right"></div>
            <nav class="drawermenu">
                <ul>
                    <li><a href="index.php" class="text-uppercase">Home</a></li>
                    <li><a href="about.php" class="text-uppercase">About</a></li>
                    <li><a href="projects.php" class="text-uppercase">Projects</a>
                    </li>
                    <li><a href="appointment.php" class="text-uppercase">Appointment</a> </li>
                    <li><a href="contact.php" class="text-uppercase">Contact</a> </li>
                </ul>
            </nav>
            <div class="drawermenu-overlay"></div>
        </div>
        <div class="right2"><a href="index.php"><img src="img/logo1header.png"></a></div>
        <div class="left1">
            <div class="decorationlefttoright"></div>
        </div>
        <nav class="left2">
            <ul class="fixedul">
                <li><a href="index.php">Home</a></li>
                <li><a href="about-laptop.php">About</a></li>
                <li><a href="projects-laptop.php">Projects</a></li>
                <li><a href="appointment-laptop.php">Appointment</a></li>
                <li><a href="contact-laptop.php">Contact</a></li>
            </ul>
        </nav>
        <div class="middle">
            <div class="decorationbottom"></div>
        </div>
        <div class="clearfix"></div>
    </header>

    <a id="backToTop">BACK TO TOP</a>
