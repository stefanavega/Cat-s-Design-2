<?php
$mysqli = new mysqli("127.0.0.1", "root", "", "atestat", 3306);
if ($mysqli->connect_errno) {
    die("The appointment could not be registered. We are working on fixing this error. Please try again later or call us!");
}

if(isset($_POST['name']) && isset($_POST['surname']) && isset($_POST['email']) && isset($_POST['message'])) {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $email = $_POST['email'];
    $message = $_POST['message'];
    $res = mysqli_query($mysqli, "INSERT INTO messages (name, surname, email, message) VALUES ('$name', '$surname', '$email', '$message')");
    if(!$res) {
        die("The appointment could not be registered. We are working on fixing this error. Please try again later or call us!");
    };
    mysqli_close ($mysqli);
    header('Location: addedmessage.php');
};
?>
