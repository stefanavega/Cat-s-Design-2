<?php
$mysqli = new mysqli("127.0.0.1", "root", "", "atestat", 3306);
if ($mysqli->connect_errno) {
    die("The appointment could not be registered. We are working on fixing this error. Please try again later or call us!");
};

if(isset($_POST['name']) && isset($_POST['surname']) && isset($_POST['email']) && isset($_POST['date']) && isset($_POST['time'])) {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $email = $_POST['email'];
    $ashly = isset($_POST['AshlyWu']) ? 1 : 0;
    $cathryn = isset($_POST['CathrynMaters']) ? 1 : 0;
    $tyler = isset($_POST['TylerWats']) ? 1 : 0;
    $mary = isset($_POST['MaryJoy']) ? 1 : 0;
    $date = $_POST['date'];
    $time = $_POST['time'];
    $message = $_POST['message'];
    $res = mysqli_query($mysqli, "INSERT INTO appointments (name, surname, email, ashly, cathryn, tyler, mary, date, time, message) VALUES ('$name', '$surname', '$email', '$ashly', '$cathryn', '$tyler', '$mary', '$date', '$time', '$message')");
    if(!$res) {
        die("The appointment could not be registered. We are working on fixing this error. Please try again later or call us!");
    };
    mysqli_close ($mysqli);
    header('Location: addedappoint.php');
};

?>
