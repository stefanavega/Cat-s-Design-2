<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>

<script type="text/javascript" src="js/jquery.es-drawermenu.js"></script>
<script type="text/javascript" src="js/datepicker.js"></script>

<script>
    $('.drawermenu').drawermenu({
        // change the speed of the drawer
        speed: 100,
        // If position: right, draw from the right
        position: 'left'
    });

    $('nav li').hover(
        function() {
            $('ul', this).stop().slideDown(200);
        },
        function() {
            $('ul', this).stop().slideUp(200);
        }
    );


    $(".datepick").datepicker();

    $('.datepick').change(
        function() {
            $('.datepicker-container').css('display', 'none');
        }
    )

    $('.datepick').focus(
        function() {
            $(".datepick").datepicker();
            $('.datepicker-container').css('display', 'block');
        }
    )

</script>
<script type="text/javascript" src="js/jquery.fullPage.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#fullpage').fullpage({
            //Navigation
            menu: '#menu',
            lockAnchors: false,
            anchors: ['firstPage', 'secondPage', 'thirdPage', 'fourthPage', 'fifthPage', 'sixthPage', 'seventhPage', 'eightPage'],
            navigation: false,
            navigationPosition: 'right',
            navigationTooltips: ['firstSlide', 'secondSlide', 'thirdSlide', 'fourthSlide', 'fifthSlide'],
            showActiveTooltip: false,
            slidesNavigation: false,
            slidesNavPosition: 'bottom',

            //Scrolling
            css3: true,
            scrollingSpeed: 700,
            autoScrolling: true,
            fitToSection: true,
            fitToSectionDelay: 1000,
            scrollBar: false,
            easing: 'easeInOutCubic',
            easingcss3: 'ease',
            loopBottom: false,
            loopTop: false,
            loopHorizontal: true,
            continuousVertical: true,
            continuousHorizontal: true,
            scrollHorizontally: false,
            interlockedSlides: false,
            dragAndMove: false,
            offsetSections: false,
            resetSliders: false,
            fadingEffect: false,
            normalScrollElements: '',
            scrollOverflow: false,
            scrollOverflowReset: false,
            scrollOverflowOptions: null,
            touchSensitivity: 15,
            normalScrollElementTouchThreshold: 5,
            bigSectionsDestination: null,

            //Accessibility
            keyboardScrolling: true,
            animateAnchor: true,
            recordHistory: true,

            //Design
            controlArrows: true,
            verticalCentered: true,
            sectionsColor: '',
            paddingTop: 0,
            paddingBottom: 0,
            fixedElements: '#header, .footer',
            responsiveWidth: 0,
            responsiveHeight: 0,
            responsiveSlides: false,
            parallax: false,
            parallaxOptions: {
                type: 'reveal',
                percentage: 62,
                property: 'translate'
            },

            //Custom selectors
            sectionSelector: '.section',
            slideSelector: '.slide',

            lazyLoading: true,

            //events
            onLeave: function(index, nextIndex, direction) {
                //it won't scroll if the destination is the 3rd section
                if (nextIndex == 1 && $('body').hasClass('modal-open')) {
                    return false;
                }
            },
            afterLoad: function(anchorLink, index) {},
            afterRender: function() {},
            afterResize: function() {},
            afterResponsive: function(isResponsive) {},
            afterSlideLoad: function(anchorLink, index, slideAnchor, slideIndex) {},
            onSlideLeave: function(anchorLink, index, slideIndex, direction, nextSlideIndex) {}
        });
    });

</script>
<script>
    var triggerA = $('.AshlyWu');
    var triggerC = $('.CathrynMaters');
    var triggerT = $('.TylerWats');
    var triggerM = $('.MaryJoy');
    var x = 0;
    triggerA.on('click', function() {
        x = 1;
        $("#AshlyWu").attr('checked', true);
    })
    triggerC.on('click', function() {
        x = 1;
        $("#CathrynMaters").attr('checked', true);
    })
    triggerT.on('click', function() {
        x = 1;
        $("#TylerWats").attr('checked', true);
    })
    triggerM.on('click', function() {
        x = 1;
        $("#MaryJoy").attr('checked', true);
    })
    $('#exampleModalLong').on('show.bs.modal', function() {
        $('.modal-backdrop.fade').css('opacity', 0.5);
        $('.modal.fade.in').css({
            'opacity': 1,
        });
        $('.modal-dialog').css({
            'top': '65px',
        });
    })
    $('#exampleModalLong').on('hide.bs.modal', function() {
        if (x === 1) {
            $('input[type=checkbox]').attr('checked', false)
        }
    })

</script>

<script>
    $('.carousel').carousel()

</script>

<script>
    function initMap() {
        var uluru = {
            lat: 45.7573,
            lng: 21.2288
        };
        var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 16,
            center: uluru
        });
        var marker = new google.maps.Marker({
            position: uluru,
            map: map
        });
    }

</script>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCQ7likSC31BOMFzLxOBbz90vNSbKZNA-c&callback=initMap">


</script>

<script>
    var backToTop = $('#backToTop');
    $(window).on('scroll', function() {
        var scrolled = $(this).scrollTop();
        if (scrolled > 200) {
            backToTop.css('display', 'block');
        } else {
            backToTop.css('display', 'none');
        }
    });

    $(window).resize(function() {
        if ($(window).width() < 992) {
            backToTop.on('click', function() {
                $(window).scrollTop(0, 0);
            })
        } else {
            backToTop.attr("href", "#firstPage");
        }
    });

    if ($(window).width() < 992) {
        backToTop.on('click', function() {
            $(window).scrollTop(0, 0);
        })
    } else {
        backToTop.attr("href", "#firstPage");
    }

</script>

</body>

</html>
