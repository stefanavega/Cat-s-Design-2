<!DOCTYPE html>
<html lang="ro">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cat's Design</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/simpleParallax.css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans:700" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/style1.css">
</head>

<body class="indexbody">
    <div class="background"></div>
    <div class="parallax" data-parallax-axis="both" data-parallax-scope="global" data-parallax-detect="mouseover">
        <div class="parallax__item" data-parallax-depth="10" style="top: -25.35px; left: 58.8px;">
            <img src="img/cloud.png" class="imgindex">
        </div>
    </div>

    <div class="indexlogo"><img class="imgindex" src="img/logo1.png"></div>
    <div class="clearfix"></div>

    <div class="container-fluid mt-5 pt-5 navlinks">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 text-center">
                <div class="nav_links text-uppercase">
                    <a id="about">about</a>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 text-center">
                <div class="nav_links text-uppercase">
                    <a id="projects">projects</a>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 text-center">
                <div class="nav_links text-uppercase">
                    <a id="appointment">appointment</a>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-3 col-xl-3 text-center">
                <div class="nav_links text-uppercase">
                    <a id="contact">contact</a>
                </div>
            </div>

        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="js/simpleParallax.min.js"></script>
    <script>
        $(document).ready(function() {
            if ($(window).width() < 992) {
                $('#about').attr('href', 'about.php');
                $('#contact').attr('href', 'contact.php');
                $('#appointment').attr('href', 'appointment.php');
                $('#projects').attr('href', 'projects.php');
            } else {
                $('#about').attr('href', 'about-laptop.php');
                $('#contact').attr('href', 'contact-laptop.php');
                $('#appointment').attr('href', 'appointment-laptop.php');
                $('#projects').attr('href', 'projects-laptop.php');
            }
        });


        $(window).resize(function() {
            if ($(window).width() < 992) {
                $('#about').attr('href', 'about.php');
                $('#contact').attr('href', 'contact.php');
                $('#appointment').attr('href', 'appointment.php');
                $('#projects').attr('href', 'projects.php');
            } else {
                $('#about').attr('href', 'about-laptop.php');
                $('#contact').attr('href', 'contact-laptop.php');
                $('#appointment').attr('href', 'appointment-laptop.php');
                $('#projects').attr('href', 'projects-laptop.php');
            }
        });

    </script>

</body>

</html>
