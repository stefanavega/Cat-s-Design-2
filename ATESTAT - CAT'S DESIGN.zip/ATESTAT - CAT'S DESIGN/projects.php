<?php require 'src/header.php';?>
<?php require 'src/functions.php';?>
<div class="container-fluid mt-5">
    <div class="col-12 offset-lg-1 col-lg-10">

        <div class="row h1decoration">
            <div class="col-12 mb-3">
                <h1 class="text-uppercase pt-5">Projects</h1>
                <div class="deco_title"></div>
            </div>
        </div>

        <div class="row">
            <div class="col-12 text-uppercase mb-3">
                <ul class="list-unstyled text-uppercase">
                    <li><a id="minimalist">Minimalist design</a></li>
                    <li><a id="scandinavian">Scandinavian design</a></li>
                    <li><a id="modern">Modern design</a></li>
                    <li><a id="contemporaryint">Contemporary interior design</a></li>
                    <li><a id="contemporarygar">Contemporary gardens</a></li>
                    <li><a id="contemporaryext">Contemporary exterior design and architecture</a></li>
                </ul>
            </div>
        </div>

        <?php $posttype=getPostType();
        for($i =0; $i<sizeOf($posttype); $i++):?>
        <div class="row <?=$posttype[$i]['class']?> posttype mb-5">
            <div class="col-12">
                <div class="row">
                    <div class="col-12 col-md-4">
                        <div class="text-uppercase">
                            <h3>
                                <?=$posttype[$i]['title']?>
                            </h3>
                        </div>
                    </div>
                    <div class="col-12 col-md-3 order-md-9">
                        <div class="p">
                            <?=$posttype[$i]['description']?>
                        </div>
                    </div>
                    <div class="col-12 offset-md-0 col-md-5">
                        <div id="carousel<?=$i?>" class="carousel slide" data-ride="carousel<?=$i?>">
                            <ol class="carousel-indicators">
                                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img class="d-block w-100" src="<?=$posttype[$i]['img1']?>" alt="First slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="<?=$posttype[$i]['img2']?>" alt="Second slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="<?=$posttype[$i]['img3']?>" alt="Third slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="<?=$posttype[$i]['img4']?>" alt="Fourth slide">
                                </div>
                            </div>
                            <a class="carousel-control-prev" href="#carousel<?=$i?>" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
                            <a class="carousel-control-next" href="#carousel<?=$i?>" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <?php endfor;?>

        <div class="row posttype1 posttype mb-5 contemporaryext">
            <div class="col-12">
                <div class="row">
                    <div class="col-12 col-md-4">
                        <div class="text-uppercase">
                            <h3>Contemporary</h3>
                            <h3>Exterior</h3>
                            <h3>design</h3>
                            <h3>and</h3>
                            <h3>architecture</h3>
                        </div>
                    </div>
                    <div class="col-12 offset-md-1 col-md-2 order-md-9">
                        <div class="p">Contemporary architects recognize the human need for contact with nature, right down to what our homes are made of. Countertops, roofing and flooring made of composite materials are hot, as are low-emission paints and carpeting. Today’s houses often feature ample skylights and large windows to let the sun shine in.</div>
                    </div>
                    <div class="col-12 col-sm-8 offset-sm-2 offset-md-0 col-md-5">
                        <div id="carousel17" class="carousel slide" data-ride="carousel17">
                            <ol class="carousel-indicators">
                                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="5"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="6"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="7"></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img class="d-block w-100" src="img/contemporary-arch/house1.jpg" alt="First slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="img/contemporary-arch/house2.jpg" alt="Second slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="img/contemporary-arch/house3.jpg" alt="Third slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="img/contemporary-arch/house4.jpg" alt="Fourth slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="img/contemporary-arch/house5.jpg" alt="Fifth slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="img/contemporary-arch/house6.jpg" alt="Sixth slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="img/contemporary-arch/house7.jpg" alt="Seventh slide">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="img/contemporary-arch/house8.jpg" alt="Eight slide">
                                </div>
                            </div>
                            <a class="carousel-control-prev" href="#carousel17" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
                            <a class="carousel-control-next" href="#carousel17" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>

</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
    $(window).resize(function() {
        if ($(window).width() >= 992) {
            window.location = "projects-laptop.php"
        };
    });
    if ($(window).width() >= 992) {
        window.location = "projects-laptop.php"
    };

    var scan = $("#scandinavian");
    var mini = $("#minimalist");
    var mod = $("#modern");
    var conint = $("#contemporaryint");
    var congar = $("#contemporarygar");
    var conext = $("#contemporaryext");
    var post = $('.posttype1');

    scan.on('click', function() {
        if ($('.scandinavian').css('display') == 'block') {
            $('.scandinavian').css('display', 'none');
        }
        if (post.hasClass('scandinavian')) {
            post.css('display', 'none');
            $('.scandinavian').css('display', 'block');
        }
    });
    mini.on('click', function() {
        if (post.hasClass('minimalist')) {
            post.css('display', 'none');
            $('.minimalist').css('display', 'block');
        }
    });
    mod.on('click', function() {
        if (post.hasClass('modern')) {
            post.css('display', 'none');
            $('.modern').css('display', 'block');
        }
    });
    conint.on('click', function() {
        if (post.hasClass('contemporary')) {
            post.css('display', 'none');
            $('.contemporary').css('display', 'block');
        }
    });
    congar.on('click', function() {
        if (post.hasClass('contemporarygar')) {
            post.css('display', 'none');
            $('.contemporarygar').css('display', 'block');
        }
    });
    conext.on('click', function() {
        if (post.hasClass('contemporaryext')) {
            post.css('display', 'none');
            $('.contemporaryext').css('display', 'block');
        }
    });

</script>
<?php require 'src/footer.php';?>
