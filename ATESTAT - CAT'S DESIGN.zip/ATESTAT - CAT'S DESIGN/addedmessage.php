<?php require 'src/header.php'?>

<div class="mt-5" style="height: 100%">
    <div id="fullpage">
        <div class="section" id="section0">
            <div class="content container-fluid pl-5 pr-5">
                <div class="row h1decoration1">
                    <div class="col-12">
                        <h1 class="text-uppercase">Your message has been recorded and you will receive a confirmation email as soon as possible. Thank you!</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<?php require 'src/footer.php';?>
