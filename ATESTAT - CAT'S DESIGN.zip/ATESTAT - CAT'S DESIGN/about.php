<?php require 'src/header.php'?>
<?php require 'src/functions.php'?>
<?php require 'src/modal.php'?>

<div class="container-fluid mt-5" id="top">
    <div class="col-12 offset-lg-1 col-lg-10">
        <div class="row h1decoration">
            <div class="col-12 mb-5">
                <h1 class="pt-5 text-uppercase">WHO WE ARE</h1>
                <div class="deco_title"></div>
            </div>
        </div>

        <?php $about = getAbout();
                for($i=0; $i<sizeOf($about); $i++):?>
        <div class="row">
            <div class="missions mb-5 pt-5 pb-5 pl-5 pr-5">
                <div class="col-12 text-uppercase">
                    <h4>
                        <?=$about[$i]['title']?>
                    </h4>
                    <div class="missionsline"></div>
                </div>
                <div class="col-12">
                    <p>
                        <?=$about[$i]['description']?>
                    </p>
                </div>
            </div>
        </div>
        <?php endfor;?>


        <div class="mb-5">
            <div class="row h1decoration">
                <div class="col-12">
                    <h1 class="pt-5 text-uppercase">Our team</h1>
                    <div class="deco_title"></div>
                </div>
            </div>
        </div>
        <?php $employees = getEmployees();
                for ($i=0; $i<sizeOf($employees); $i++):?>
        <div class="designer row mb-5">
            <div class="designerimg col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 text-center mb-2 mb-lg-0 mb-xl-0">
                <img src="<?=$employees[$i]['img']?>" class="img img-fluid">
            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                <div class="interiordesigner text-center mb-4">
                    <p class="text-uppercase">
                        <?=$employees[$i]['job']?>:
                            <?=$employees[$i]['name']?>
                    </p>
                </div>
                <div class="aboutdesigner">
                    <div class="interiordesigner mb-2">
                        <p class="text-capitalize">
                            <?=$employees[$i]['specialization']?>
                        </p>
                    </div>
                    <p class="mb-3">
                        <?=$employees[$i]['description']?>
                    </p>
                </div>
                <div class="row makeappoint">
                    <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                        <a class="text-uppercase <?=$employees[$i]['class']?>" data-toggle="modal" id="appointtrigger" href="#exampleModalLong">Make an appointment</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endfor;?>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script>
            $(window).resize(function() {
                if ($(window).width() >= 992) {
                    window.location = "about-laptop.php"
                };
            });
            if ($(window).width() >= 992) {
                window.location = "about-laptop.php"
            };

        </script>


        <?php require 'src/footer.php';?>
