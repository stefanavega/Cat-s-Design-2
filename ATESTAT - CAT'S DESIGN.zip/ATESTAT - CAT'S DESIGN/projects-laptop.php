<?php require 'src/header.php'?>
<?php require 'src/functions.php'?>

<div class="mt-5" style="height: 100%">
    <div id="fullpage">
        <div class="section" id="section0">
            <div class="content container-fluid pl-5 pr-5">

                <?php $domains=getDomains();
                    for($i=0; $i<sizeOf($domains); $i++):?>

                <h3 class="mb-3 text-uppercase">
                    <a class="menu" href="#<?=$domains[$i]['index']?>Page">
                        <?=$domains[$i]['title']?>
                    </a>
                </h3>

                <?php endfor;?>

            </div>
        </div>
        <?php $domains=getDomains();
              for ($k=0; $k<(sizeOf($domains)); $k++):?>
        <div class="section" id="section<?=($k+1)?>">
            <div class="slide" id="slide<?=($k+1)?>">
                <div class="content">
                    <h3 class="text-uppercase">
                        <?=$domains[$k]['title']?>
                    </h3>
                </div>
            </div>
            <?php 
            if($k==0) {$design = getScandinavian();
                       $var = 20;}
            if($k==1) {$design = getMinimalist();
                       $var = 30;}
            if($k==2) {$design = getModern();
                       $var = 40;}
            if($k==3) {$design = getContemporaryInt();
                       $var = 50;}
            if($k==4) {$design = getContemporaryGard();
                       $var = 60;}
            if($k==5) {$design = getContemporaryExt();
                       $var = 70;}
             for ($i=0; $i<sizeOf($design); $i++):
            ?>
            <div class="slide" id="slide<?=($i+2)?>">
                <div class="content container-fluid">
                    <div class="row left">
                        <div class="col-6 text-left right1">
                            <h4>
                                <?=$design[$i]['title']?>
                            </h4>
                            <p class="mt-4">
                                <?=$design[$i]['description']?>
                            </p>
                        </div>
                        <div class="col-6 image1">
                            <div id="carousel<?=($i+$var)?>" class="carousel slidecarousel" data-ride="carousel<?=($i+$var)?>">
                                <ol class="carousel-indicators">
                                    <?php if($k < 4):?>
                                    <?php for($j=0; $j<sizeOf($design); $j++):?>
                                    <li data-target="#carouselExampleIndicators" data-slide-to="<?=$j?>" class="active"></li>
                                    <?php endfor;?>
                                    <?php endif;?>
                                    <?php if($k == 4):?>
                                    <?php for($j=0; $j<4; $j++):?>
                                    <li data-target="#carouselExampleIndicators" data-slide-to="<?=$j?>" class="active"></li>
                                    <?php endfor;?>
                                    <?php endif;?>
                                    <?php if($k == 5):?>
                                    <?php for($j=0; $j<8; $j++):?>
                                    <li data-target="#carouselExampleIndicators" data-slide-to="<?=$j?>" class="active"></li>
                                    <?php endfor;?>
                                    <?php endif;?>
                                </ol>
                                <div class="carousel-inner">
                                    <?php if ($k<4):?>
                                    <div class="carousel-item active">
                                        <img class="d-block w-100" src="<?=$design[$i]['img1']?>" alt="First slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block w-100" src="<?=$design[$i]['img2']?>" alt="Second slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block w-100" src="<?=$design[$i]['img3']?>" alt="Third slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block w-100" src="<?=$design[$i]['img4']?>" alt="Fourth slide">
                                    </div>
                                    <?php endif;?>
                                    <?php if ($k == 4):?>
                                    <div class="carousel-item active">
                                        <img class="d-block w-100" src="<?=$design[$i]['img1']?>" alt="First slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block w-100" src="<?=$design[$i]['img2']?>" alt="Second slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block w-100" src="<?=$design[$i]['img3']?>" alt="Third slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block w-100" src="<?=$design[$i]['img4']?>" alt="Fourth slide">
                                    </div>
                                    <?php endif;?>
                                    <?php if ($k == 5):?>
                                    <div class="carousel-item active">
                                        <img class="d-block w-100" src="<?=$design[$i]['img1']?>" alt="First slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block w-100" src="<?=$design[$i]['img2']?>" alt="Second slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block w-100" src="<?=$design[$i]['img3']?>" alt="Third slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block w-100" src="<?=$design[$i]['img4']?>" alt="Fourth slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block w-100" src="<?=$design[$i]['img5']?>" alt="Fifth slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block w-100" src="<?=$design[$i]['img6']?>" alt="Sixth slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block w-100" src="<?=$design[$i]['img7']?>" alt="Seventh slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block w-100" src="<?=$design[$i]['img8']?>" alt="Eight slide">
                                    </div>
                                    <?php endif;?>
                                </div>
                                <a class="carousel-control-prev" href="#carousel<?=($i+$var)?>" role="button" data-slide="prev"><span class="carousel-control-prev-icon" aria-hidden="true"></span><span class="sr-only">Previous</span></a>
                                <a class="carousel-control-next" href="#carousel<?=($i+$var)?>" role="button" data-slide="next"><span class="carousel-control-next-icon" aria-hidden="true"></span><span class="sr-only">Next</span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endfor;?>
        </div>
        <?php endfor;?>



        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script>
            $(window).resize(function() {
                if ($(window).width() < 992) {
                    window.location = "projects.php"
                };
            });
            if ($(window).width() < 992) {
                window.location = "projects.php"
            };

        </script>

        <?php require 'src/footer.php'?>
