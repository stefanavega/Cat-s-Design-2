<?php require 'src/header.php'?>
<?php require 'src/add/addappointment.php'?>
<div class="mt-5" style="height: 100%">
    <div id="fullpage">
        <div class="section" id="section0">
            <div class="slide" id="slide1">
                <div class="content container-fluid pl-5 pr-5">
                    <div class="row h1decoration1">
                        <div class="col-12">
                            <h1 class="text-uppercase">Make an appointment</h1>
                            <div class="deco_title" style="top: 42px;"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 mb-5">
                            <h5 class="gotocontact">In case you only wish to send us a simple message click <a href="contact.php">here</a>!</h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="section" id="section1">
            <div class="slide" id="slide1">
                <div class="content container-fluid pl-5 pr-5">
                    <div class="row">
                        <div class="col-12">
                            <form class="text-uppercase" method="post">
                                <div class="row">
                                    <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 text-left">
                                        <div class="form-group mb-3">
                                            <label for="name">Name</label>
                                            <input type="text" class="form-control left" id="name" placeholder="Name" required name="name">
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="surname">Surname</label>
                                            <input type="text" class="form-control left" id="surname" placeholder="Surname" required name="surname">
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="email">Email address</label>
                                            <input type="email" class="form-control left" id="email" placeholder="name@example.com" required name="email">
                                        </div>
                                        <p class="text-uppercase mb-2">Select which of our employees you would like to meet with!</p>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1" id="AshlyWu" name="AshlyWu">
                                            <label class="form-check-label" for="AshlyWu">Interior Designer: Ashly Wu (Scandinavian/Minimalist)</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1" id="CathrynMaters" name="CathrynMaters">
                                            <label class="form-check-label" for="CathrynMaters">Interior Designer: Cathryn Maters (Modern/Contemporary)</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1" id="TylerWats" name="TylerWats">
                                            <label class="form-check-label" for="TylerWats">Exterior/Garden Designer: Tyler Wats</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="1" id="MaryJoy" name="MaryJoy">
                                            <label class="form-check-label" for="MaryJoy">Architect: Mary Joy</label>
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-12 col-md-12 offset-lg-0 col-lg-6 col-xl-6 text-right rightinputs">
                                        <div class="form-group mt-5 mt-lg-0">
                                            <label for="date">The date of your appointment</label>
                                            <input type="text" datepicker type="text" class="form-control datepick right" id="date" placeholder="" required name="date">
                                        </div>
                                        <div class="form-group mt-3">
                                            <label for="hour">The time of your appointment (hh:mm AM/PM)</label>
                                            <input type="time" class="form-control right" id="hour" required name="time">
                                        </div>

                                        <div class="form-group mt-3">
                                            <label for="message">Leave us a message if you'd like!</label>
                                            <textarea class="form-control right" id="message" rows="5" placeholder="Write here!" name="message" maxlength="1500"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5 mt-5">
                                    <div class="col-6 text-left">
                                        <button type="reset" class="appointment btn text-uppercase left text-left">Reset</button>
                                    </div>
                                    <div class="offset-0 col-6 text-right">
                                        <button type="submit" class="appointment btn text-uppercase right text-right">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
    $(window).resize(function() {
        if ($(window).width() < 992) {
            window.location = "appointment.php"
        };
    });
    if ($(window).width() < 992) {
        window.location = "appointment.php"
    };

</script>
<?php require 'src/footer.php'?>
